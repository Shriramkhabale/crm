//models/Company.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const companySchema = new mongoose.Schema({
  superadmin: { type: mongoose.Schema.Types.ObjectId, ref: 'Superadmin' },
  franchise: { type: mongoose.Schema.Types.ObjectId, ref: 'Franchise' },
  businessName: { type: String, required: true },
  businessEmail: { type: String, required: true, unique: true, lowercase: true },
  businessPhone: { type: String },
  EmergencyMobNo: { type: String },
  password: { type: String, required: true },
  businessCreatedDate: { type: Date },
  businessSubscriptionPlan: { type: String },
  weeklyHoliday: { type: [String] },
  address: { type: String },
  isBranch: { type: Boolean, default: false },
  parentCompanyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Company', default: null },
  branches: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Company' }] ,
  businessLogo: { type: String },
  userLimit: { type: Number, default: 0 },
   // New fields for password reset
  resetPasswordToken: {
    type: String,  // Hashed token
  },
  resetPasswordExpires: {
    type: Date,  // Expiration timestamp
  },
}, { timestamps: true });

// Indexes for efficient queries (superadmin/franchise lookup, branch filtering)
companySchema.index({ superadmin: 1 });
companySchema.index({ franchise: 1 });
companySchema.index({ parentCompanyId: 1, isBranch: 1 });

// Hash password before saving
companySchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();

  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (err) {
    next(err);
  }
});

module.exports = mongoose.model('Company', companySchema);